
public class ThreadNameDemo extends Thread {
	public void run() {
		System.out.println("Run:"+Thread.currentThread().getName());
	}
	public static void main(String[] args) throws Exception{
		// TODO Auto-generated method stub
		System.out.println(Thread.currentThread().getName());//main
		/*Thread.currentThread().setName("Yash");
		System.out.println(Thread.currentThread().getName());//yash*/
		
		ThreadNameDemo t1=new ThreadNameDemo();
		t1.setName("T1");
		t1.start();
		ThreadNameDemo t2=new ThreadNameDemo();
		t2.setName("T2");
		t2.start();
	}
}
