
public class ThreadSleepDemo2 extends Thread {
	public void run()
	{
		for(int i=1;i<=3;i++) {
			try {
				System.out.println(Thread.currentThread().getName());
			}
			catch(Exception e) {
				e.printStackTrace();
			}
			System.out.println(i);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadSleepDemo2 ts=new ThreadSleepDemo2();
		ts.setName("YashTech");
		ts.setPriority(10);
		ts.start();
		ThreadSleepDemo2 ts1=new ThreadSleepDemo2();
		ts1.setName("Rakshada");
		ts.setPriority(1);
		ts1.start();

	}

}
