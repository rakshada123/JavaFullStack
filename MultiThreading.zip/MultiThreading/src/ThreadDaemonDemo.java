
public class ThreadDaemonDemo extends Thread{
	public void run()
	{
		if(Thread.currentThread().isDaemon())
		{
			System.out.println("in Daemon thread");
		}
		else
		{
			System.out.println("I am in non-Daemon thread");
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Main Thread");
		ThreadDaemonDemo td = new ThreadDaemonDemo();
		td.setDaemon(true);
		td.start();
	}

}
