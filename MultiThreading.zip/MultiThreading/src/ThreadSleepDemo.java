
public class ThreadSleepDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		try {
			for(int i=1;i<=3;i++) {
				Thread.sleep(6000);
				System.out.println(i);
			}
		}
		catch(Exception e) {
			e.printStackTrace();
		}

	}

}
