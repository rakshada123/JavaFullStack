
public class ThreadDemo extends Thread{
	public void run()
	{
		System.out.println("Thread Started");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo t=new ThreadDemo();
		t.start(); //start is used to create a new thread and to make it runnable.this new thread begins inside the run() method
	}

}
