
public class ThreadJoinDemo extends Thread {
	public void run() {
		try {
			for(int i=1;i<=3;i++) {
				System.out.println("run thread"+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
		try {
			for(int i=1;i<=3;i++) {
				System.out.println("Main thread"+i);
				Thread.sleep(1000);
			}
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		ThreadJoinDemo tj=new ThreadJoinDemo();
		tj.start();
		tj.join();
		

	}

}
