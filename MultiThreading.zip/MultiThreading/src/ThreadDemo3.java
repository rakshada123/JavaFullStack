
public class ThreadDemo3 extends Thread {
	public void run()
	{
		System.out.println("Thread Started");
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ThreadDemo3 td=new ThreadDemo3();
		td.start();
		ThreadDemo3 t=new ThreadDemo3();
		t.start();
		

	}

}
