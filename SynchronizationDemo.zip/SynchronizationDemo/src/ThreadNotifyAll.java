class Revenue extends Thread
{
	public void run() {
		synchronized(this)
		{
			System.out.println("Start of" + Thread.currentThread().getName());
			try
			{
				this.wait();
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
			
			System.out.println(Thread.currentThread().getName()+" notified");
		}
	}
}
class Revenue2 extends Thread
{
	Revenue r;
	Revenue2(Revenue r)
	{
		this.r=r;
	}
	public void run()
	{
		synchronized(this.r)
		{
			System.out.println("Starting of " + Thread.currentThread().getName());
	        this.r.notifyAll();
	        System.out.println(Thread.currentThread().getName() + "...notified");  
		}
    }  
}    


public class ThreadNotifyAll {
	 public static void main(String[] args) throws InterruptedException
	 {
		 Revenue r=new Revenue();
		 Revenue2 r2 = new Revenue2(r);
		 Thread t1=new Thread(r,"Thread-1");
		 Thread t2=new Thread(r2,"Thread-2");
		 t1.start();

		 t2.start();
		 
	 }
}


