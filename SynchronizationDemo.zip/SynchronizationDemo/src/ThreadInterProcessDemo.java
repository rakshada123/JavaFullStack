class Revenue extends Thread
{
	int total = 0;
	public void run()
	{
		synchronized(this) {
			for(int i=1;i<=5;i++)
			{
				total = total+400;
			}
			this.notify();//lock again given to main
		}
	}
}

public class ThreadInterProcessDemo {
	public static void main(String[] args) throws Exception{
		Revenue r=new Revenue();
		r.start();//thread - 0
		//System.out.println("Total Amount" + r.total);
		synchronized(r)
		{
			r.wait(1);//object lock main given to thread-0
			System.out.println("Total Amount" + r.total);
		}
	}

}
