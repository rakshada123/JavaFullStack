
public class BookTicket {

	static int totalseats=12;
	 static synchronized void bookseat(int seats)
	     {
		      if(totalseats>=seats)
			  {
			      System.out.println("Booked Successfully");
				  totalseats=totalseats-seats;
				  System.out.println("Remaining seats: "+totalseats);
			  }
			  else
			  {
			      System.out.println("Seats are not available: " +totalseats);
			  }
	     }

}
class Thread1 extends Thread1
				{
				    static BookTicket b;
					int seats;
					Thread1(BookTicket b,int seats)
					{
					   this.b=b;
					   this.seats=seats;
				    }
					public void run() {
				}
			}
			pblic class TicketSynchro extends Thread{
			}
			public static void main(String[] args) {
			    BookTicket b=new BookTicket();
				Thread1 t1=new Thread1(b,8);
				t1.start();
				Thread2 t2= new Thread(b,3);
				t2.start();
				BookTicket b1=new BookTicket();
				Thread1 t3=new Thread1(b1,3);
				t3.start();
				Thread2 t4=new Thread2(b1,4);
				t4.start();
				}
				}
				

	}

}
