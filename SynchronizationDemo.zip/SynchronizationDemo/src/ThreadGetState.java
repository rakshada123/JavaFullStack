
public class ThreadGetState extends Thread { 
	   public void run()   
	    {  
	         
	        Thread.State state = Thread.currentThread().getState();  
	        System.out.println("Running thread name: "+ Thread.currentThread().getName());  
	        System.out.println("thread state: " + state);  
	    }  
	    public static void main(String args[])   
	    {  
	        ThreadGetState g = new ThreadGetState();  
			Thread t1=new Thread(g);
			Thread t2=new Thread(g);
	        
	        t1.start();     
	        t2.start();  
	    }  
	}  


