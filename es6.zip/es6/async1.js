function result(r)
{
 console.log("result"+r);
}
function sum(a,b,callbackfun)
{
  var s=a+b;
  callbackfun(s);
}
sum(10,22,result);