const names = new Set( [ "anil","sunil","vijay"]);

console.log(names.size);
names.add("vikram");
names.add("vikas");
names.add("vinit");
console.log(names.size);
for (let x of names.values())
	  console.log(x);
  
 names.delete("vikas"); 
 console.log("after deletion");
 for (let x of names.values())
	  console.log(x);
  
  names.forEach(function(v) {
	  console.log(v);
	  
  });
  
 names.add("anil"); 
 console.log("After adding anil again ");
 names.forEach(function(v) {
	  console.log(v);
	  
  });