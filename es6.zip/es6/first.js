var a=10;
/*console.log(a);
console.log("this is demo of console.log");
let x=9;
{
	let x=4;
	 console.log(x);
}
console.log(x);
*/
var b=12;
var b=34;
console.log(b);
let c=122;
//let c=334;
console.log(c);