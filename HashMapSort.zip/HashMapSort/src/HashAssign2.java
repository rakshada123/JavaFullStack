import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Properties;
import java.util.Set;
public class HashAssign2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Properties p = new Properties();
		
		p.setProperty("Chattisgarh", "Raipur");
		p.setProperty("Madhya Pradesh", "Bhopal");
		p.setProperty("Maharashtra", "Pune");

		Set<Entry<Object, Object>> set = p.entrySet();
		Iterator<Entry<Object, Object>> itr = set.iterator();
		
		while (itr.hasNext()) {
			Entry<Object, Object> e = itr.next();
			System.out.println(e);
		}

	}

}

