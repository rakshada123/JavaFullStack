import java.util.Map;  
import java.util.HashMap;  
import java.util.TreeMap;  
import java.util.Iterator;  
public class Hash  
{  
	public static void main(String args[])  
	{    
		HashMap<Integer, String> hm=new HashMap<Integer, String>();  
		hm.put(10, "Rakshada");  
		hm.put(17, "Naman");  
		hm.put(15, "Sonu");  
		hm.put(9, "Neelesh");  
		Iterator <Integer> i = hm.keySet().iterator();         
		System.out.println("Before Sorting");  
		while(i.hasNext())  
		{  
			int key=(int)i.next();  
			System.out.println("Roll no:  "+key+"     name:   "+hm.get(key));  
		}  
		System.out.println("\n");  
		Map<Integer, String> map=new HashMap<Integer, String>();  
		System.out.println("After Sorting");  
		//using TreeMap constructor to sort the HashMap  
		TreeMap<Integer,String> tm=new  TreeMap<Integer,String> (hm);  
		Iterator itr=tm.keySet().iterator();               
		while(itr.hasNext())    
		{    
			int key=(int)itr.next();  
			System.out.println("Roll no:  "+key+"     name:   "+hm.get(key));  
		}    
	}  
}