
public class sqr {
	public int square(int n)
	{
		return (n*n);
	}

}
