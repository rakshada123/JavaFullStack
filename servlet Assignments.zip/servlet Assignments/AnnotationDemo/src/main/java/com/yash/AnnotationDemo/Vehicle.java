package com.yash.AnnotationDemo;

public interface Vehicle {
	void drive();
}
