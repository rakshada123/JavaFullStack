package com.yash;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

//@WebServlet("/ServletEnumDemo")
public class ServletEnumDemo extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
    public ServletEnumDemo() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		
		String name=request.getParameter("name");
		
		HttpSession session=request.getSession();
		ServletContext context=request.getServletContext();
		if(name!=null&&name!="")
		{
		session.setAttribute("name", name);
		context.setAttribute("name", name);
		}
		out.println("I am in servlet class and your name is: "+name+(String)session.getAttribute("name")+(String)context.getAttribute("name"));
		ServletConfig config=getServletConfig();
		String name2=config.getInitParameter("name");
		out.println("I am in servlet class and your name is: "+name2);
		
		Enumeration<String> enm=config.getInitParameterNames();
		String s="";
		while(enm.hasMoreElements())
		{
			s=enm.nextElement();
			out.println("<br>Name: "+s);
			out.println("value: "+config.getInitParameter(s));
		}
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
