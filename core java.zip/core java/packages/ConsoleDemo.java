import java.io.Console;
class ConsoleDemo
{
	public static void main(String[] args)
	{
		String s;
		char ch[];
		Console ob = System.console();
		System.out.println("Enter Username");
		s=ob.readLine();
		System.out.println("Enter Password");
		ch=ob.readPassword();
		System.out.println("Username:"+s+"Password"+ch);
		String a=String.valueOf(ch);
		System.out.println("Actual password:"+a);
	}
}
		