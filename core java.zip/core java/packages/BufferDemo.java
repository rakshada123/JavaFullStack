import java.io.InputStreamReader;
import java.io.BufferedReader;
class BufferDemo
{
	public static void main(String[] args)throws Exception
	{
		String str;
		InputStreamReader r=new InputStreamReader(System.in);
		BufferedReader br=new BufferedReader(r);
		str=br.readLine();
		System.out.println(str);
	}
}