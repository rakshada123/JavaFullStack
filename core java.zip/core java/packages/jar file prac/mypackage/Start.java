package mypackage;
public class Start
{
	public void display()
	{
		System.out.println("I am in Display start class");
	}
}