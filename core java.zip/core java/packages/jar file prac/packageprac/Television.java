package packageprac;
public class Television
{
	public void display()
	{
		System.out.println("TV is playing");
	}
}
	