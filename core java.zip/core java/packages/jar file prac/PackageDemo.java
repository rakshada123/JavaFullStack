import mypackage.Start;
class PackageDemo
{
	public static void main(String[] args)
	{
		//mypackage.Start ob = new mypackage.Start();- 1st way
		Start ob=new Start();
		ob.display();
		
	}
}