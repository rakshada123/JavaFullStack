import packageprac.Television;
class MyPackageDemo
{
	public static void main(String[] args)
	{
		//mypackage.Start ob = new mypackage.Start();- 1st way
		Television t=new Television();
		t.display();
		
	}
}