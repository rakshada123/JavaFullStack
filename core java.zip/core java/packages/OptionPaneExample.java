import javax.swing.*;
public class OptionPaneExample
{
	JFrame f;
	OptionPaneExample(){
		f=new JFrame();
		String n=JOptionPane.showInputDialog(f,"Enter name");
		JOptionPane.showMessageDialog(f,n);
		System.exit(0);
	}
	public static void main(String[] args){
		new OptionPaneExample();
	}
}