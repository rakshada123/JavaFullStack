class ArrSum2
{
	public static void main(String[] args)
	{
		int[][] a={{10,20,30},{40,50}};
		int sum=0;
		int count = 0;
		double average = 0;
		for(int ir[]:a)
		{
			for(int i:ir)
			{
				sum = sum + i;
				count++;
			}
		}
		average = sum/count;
		System.out.println(sum);
		System.out.println(average);
	}
}