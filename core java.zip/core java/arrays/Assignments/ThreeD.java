class ThreeD
{
	public static void main(String[] args)
	{
		int[][] a=new int[3][3];
		int count=0;
		int max=0;
		for(int i=0;i<a.length;i++)
		{
			for(int j=0;j<a[i].length;j++)
			{
				a[i][j]=Integer.parseInt(args[count++]);
				System.out.print(a[i][j]+ " ");
				if(a[i][j]>max)
				{
					max=a[i][j];
				}
			}
			System.out.println();
		}
		System.out.println("the max value of 3D array is" + max);
	}
}