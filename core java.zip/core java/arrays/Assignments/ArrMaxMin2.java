class ArrMaxMin2
{
	public static void main(String[] args)
	{
		int[] a={10,20,30,40,20};
		int max1 = a[0];
		int temp=0;
		int max2 = a[1];
		if(max1<max2)
		{
			temp=max1;
			max1=max2;
			max2=temp;
		}
		for(int i=2;i<a.length;i++)
		{
			if(a[i]>max1){
				max2 = max1;
				max1 = a[i];
			}
			else if(a[i] > max2 && a[i] != max1)
			{
				max2 = a[i];
			}
		}
		int first=max1;
		int second = max2;
		for(int i=0;i<a.length;i++){
			int curr = a[i];
			if(first>curr){
				second=first;
				first=curr;
			}
			else if(second>curr){
				second=curr;
			}
		}
		
		System.out.println(first);
		System.out.println(second);
		
		System.out.println(max1);
		System.out.println(max2);
	}
}