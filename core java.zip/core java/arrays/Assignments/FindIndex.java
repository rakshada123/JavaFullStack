class FindIndex
{
	public static void main(String[] args)
	{
		int[] a={10,80,30,40,60};
		int count = 0;
		int i;
		for(i=0;i<a.length;i++)
		{
			if(a[i] == 60)
			{
				count = 1;
				break;
			}
		}
		if(count == 1)
		{
			System.out.print(i);
		}
		else{
			System.out.println("-1");
		}
	}
}
