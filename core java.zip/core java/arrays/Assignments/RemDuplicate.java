class RemDuplicate
{
	public static void main(String[] args)
	{
		int[] a={10,40,30,40,60};
		for(int i=0;i<a.length;i++)
		{
			int num = a[i];
			for(int j=i+1;j<a.length;j++)
			{
				if(a[j] == a[i])
				{
					a[i] = 0;
				}
			}
			if(a[i] != 0){
				System.out.println(a[i] + " ");
			}
		}
	}
}