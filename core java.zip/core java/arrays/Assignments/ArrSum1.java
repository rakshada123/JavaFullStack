class ArrSum1
{
	public static void main(String[] args)
	{
		int[] a={10,20,30,40,20};
		int sum=0; double avg = 0;
		for(int i:a)
		{
			sum=sum+i;
		}
		avg = sum/a.length;
		System.out.println(sum);
		System.out.println(avg);
	}
}