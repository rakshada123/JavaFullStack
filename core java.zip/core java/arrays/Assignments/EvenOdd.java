class EvenOdd
{
	public static void main(String[] args)
	{
		int[] a={1,2,3,4};
		int[] c = new int[a.length];
		int e = 0;
		int o = c.length - 1;
		for(int i=0;i<a.length;i++)
		{
			if(a[i]%2==0)
			{
				c[e] = a[i];
				e++;
			}
			else{
				c[o]=a[i];
				o--;
			}
		}
		for(int i=0;i<c.length;i++)
		{
			System.out.print(c[i] + " ");
		}
	}
}