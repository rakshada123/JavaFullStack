class CheckArr14
{
	public static void main(String[] args)
	{
		int[] a={1,4,1,4};
		int count = 0;
		for(int i=0;i<a.length;i++)
		{
			if(a[i] == 1 || a[i] == 4)
			{
				count++;
			}
			else{
				System.out.println("false");
				break;
			}
		}
		if(count != 0)
		{
			System.out.println("true");
		}
	}
}