class Sum6to7
{
	public static void main(String[] args)
	{
		int[] a = {10,3,6,1,2,7,9};
		int sum = 0;
		boolean flag = false;
		for(int i=0;i<a.length;i++)
		{
			if(a[i] == 6 )
			{	
				flag = true;	
			}
			if(flag == true)
			{
				if(a[i] == 7){
					flag = false;
				}
				continue;
				
			}
			else{
				if(a[i] == 7)
				{
					sum += 6+a[i];
				}
				else{
					sum += a[i];
				}
			}
		}
		System.out.println(sum);
	}
}
			