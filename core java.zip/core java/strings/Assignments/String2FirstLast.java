class String2FirstLast
{
	public static void main(String[] args)
	{
		System.out.println(args[0]);
		String x=args[0];
		System.out.println(args[1]);
		String y=args[1];
		StringBuilder s = new StringBuilder();
		int n = x.length()+y.length();
		
		for(int i=0;i<x.length()||i<y.length();i++)
		{
			if(i<x.length())
			{
				s = s.append(x.charAt(i));
			}
			if(i<y.length())
			{
				s = s.append(y.charAt(i));
			}
		}
		for(int j=0;j<n;j++)
		{
			System.out.print(s.charAt(j));
		}
	}
}