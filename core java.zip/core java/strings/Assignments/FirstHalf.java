class FirstHalf
{
	public static void main(String[] args)
	{
		System.out.println(args[0]);
		String s=args[0];
		int n=s.length();
		if(n%2==0)
		{
			for(int i=0;i<n;i++)
			{
				System.out.println(s.substring(0,n-1));
			}
		}
		else{
			System.out.println("null");
		}
	}
}
			
			