class ObjCompariDemo
{
	public static void main(String[] args)
	{
		String s1=new String("Yash");
		String s2=new String("Yash");
		System.out.println(s1==s2);
		String s3="jaynam";
		String s4="jaynam";
		System.out.println(s3==s4);
		System.out.println(s1.equals(s2));
	}
}
//Link for reference:
//Uses of Class java.lang.StringBuffer (Java Platform SE 8 ) (oracle.com)