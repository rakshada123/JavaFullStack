class Palindrome
{
	public static void main(String[] args)
	{
		System.out.println(args[0]);
		String s=args[0];
		String b=new String();
		int n=s.length();
		for(int i=n-1;i>=0;i--)
		{
			b=b+s.charAt(i);
		}
		if(s.equalsIgnoreCase(b))
		{
			System.out.println("Palindrome");
		}
		else
		{
			System.out.println("Not Palindrome");
		}
	}
}