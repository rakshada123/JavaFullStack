class StringBuilder
{
	public static void main(String[] args)
	{
		
		StringBuilder sb=new StringBuilder(" Rakshada");
		sb.append("Hello");
		System.out.println(sb);
		System.out.println(sb.length());
		System.out.println(sb.capacity());
		System.out.println(sb.delete(0,6));
	}
}