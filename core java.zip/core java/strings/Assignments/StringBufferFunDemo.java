class StringBufferFunDemo
{
	public static void main(String[] args)
	{
		//StringBuffer sb=new StringBuffer("Welcome to Yash Technologies");
		String s1=new String("Yash");
		String s2=new String("Technology");
		//System.out.println(sb.deleteCharAt(7));
		String s=new String();
		System.out.println(s1.isEmpty());
		System.out.println(s.isEmpty());
		
	}
}