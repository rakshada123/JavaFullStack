class Encapsulation
{
	private int num;
	public void setNum(int num)
	{
		this.num = num;
	}
	public int getNum()
	{
		return(num);
	}
}
class Math
{
	public static void main(String[] args)
	{
		Encapsulation e = new Encapsulation();
		e.setNum(5);
		System.out.println(e.getNum());
	}
}