class subString
{
	public static void main(String[] args)
	{
		//StringBuffer sb=new StringBuffer("Welcome to Yash Technologies");
		String s1=new String("Yash");
		String s2=new String("YAsh");
		//System.out.println(s1==s2);
		String s="Rakshada";
		String s3="Rakshada Pant";
		//s1=s1.concat(" Technologies");
		//System.out.println(s1.equals(s2));
		System.out.println(s3.substring(3,7));
		//System.out.println(s==s3);
		//System.out.println(s1.compareTo(s2));
		//System.out.println(s3.compareTo(s));
		//System.out.println(s1.compareToIgnoreCase(s2));
		
		
	}
}