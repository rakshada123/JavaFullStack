class Ex3{
	public static void main(String args[]){
		int i;
		i=1;
		do {
			System.out.print("\t" + i);
			i++;
		}while(i<=200);
	}
}