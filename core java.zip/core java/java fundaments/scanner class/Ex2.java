import java.util.Scanner;
class Ex2{
	public static void main(String args[]){
		char c;
		Scanner a = new Scanner(System.in);
		c = a.next().charAt(0);
		if(c >= 'a' && c <= 'z'){
			System.out.println("Lower");
		}
		else if(c >= 'A' && c <= 'Z') {
			System.out.println("Upper");
		}
		else{
			System.out.println("Special character");
		}
	}
}