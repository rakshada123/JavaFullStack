class Assignment9
{
	static int factorial(int n){    
			if (n == 0)    
				return 1;    
			else    
				return(n * factorial(n-1));    
		}    
	public static void main(String[] args)
	{
		int i =1, fact = 1;
		int a=Integer.parseInt(args[0]);
		fact = factorial(a);
		
		System.out.println("Factorial of" + a + "is" + fact);
	}
}