class Vehicle{
}  
  
class Bike{
	void printName(Object obj){  
	Class c=obj.getClass();    
	System.out.println(c.getName());  
	}  
  
	public static void main(String args[]) throws Exception{  
 
	Vehicle s=new Vehicle();  
   
	Bike t=new Bike();  
	t.printName(s);  
	Class c = boolean.class;   
	System.out.println(c.getName());  
  
	Class c2 = Bike.class;   
	System.out.println(c2.getName());
	Class c3=Class.forName("Vehicle");
	System.out.println(c3.getName());
 }  
}  
   