class TypesVar
{
	int a = 20;//instance
	static int b=30;//static
	void add()
	{
		int c;//local
		c=a+b;
		System.out.println(c);
	}
	public static void main(String[] args)
	{
		TypesVar ob1=new TypesVar();//object created
		//a.add();
		System.out.println(ob1.a);//20
		System.out.println(ob1.b);//30
		ob1.a = 50;
		ob1.b = 450;
		System.out.println(ob1.a);//50
		System.out.println(ob1.b);//450
		TypesVar ob2=new TypesVar();
		System.out.println(ob2.a);//20
		System.out.println(ob2.b);//450
	}
}