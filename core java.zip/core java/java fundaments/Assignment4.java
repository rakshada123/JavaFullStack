class Assignment4
{
	public static void main(String[] args)
	{
		char operator;
		double a, b;
			a=Double.parseDouble(args[0]);
			b=Double.parseDouble(args[1]);
		operator = args[2].charAt(0);
		System.out.println("Enter a operator");
		double output = 0;
		switch(operator)
		{
			case '+':
				output = a + b;
				break;
				
			case '-':
				output = a - b;
				break;
			
			case '*':
				output = a*b;
				break;
				
			case '/':
				output = a/b;
				break;
				
			default:
				System.out.println("You have entered wrong operator");
				
		}
		System.out.println(a +" "+operator+" "+ b +": "+output);
	}
}