class Assignment8
{
	public static void main(String[] args)
	{
		int fact = 1;
		int a=Integer.parseInt(args[0]);
		for(int i=1;i<=a;i++){
			fact = fact*i;
		}
		System.out.println("Factorial of" + a + "is" + fact);
	}
}