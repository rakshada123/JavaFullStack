class Assignment10
{
	public static void main(String[] args)
	{
		int reverseNum = 0;
		int n=Integer.parseInt(args[0]);
		while(n != 0){
			reverseNum = reverseNum*10 + n%10;
			n = n/10;
		}
		System.out.println(reverseNum);
	}
}
			