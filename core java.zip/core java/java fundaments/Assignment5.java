class Assignment5
{
	public static void main(String[] args)
	{
		int t;
		int a=Integer.parseInt(args[0]);
		int b=Integer.parseInt(args[1]);
		System.out.println("num1:" + a + "num2:" + b);
		t=a;
		a=b;
		b=t;
		System.out.println("num1:" + a + "num2:" + b);
	}
}
		
		