class Assignment14
{
	public static void main(String[] args)
	{
		int temp, r;
		int n=Integer.parseInt(args[0]);
		temp = n;
		int sum=0;
		while(n>0)
		{
			r=n%10;    
			sum=(sum*10)+r;    
			n=n/10;
		}
		if(temp == sum){
			System.out.println("Palindrome");
		}
		else{
			System.out.println("Not Palindrome");
		}
	}
}