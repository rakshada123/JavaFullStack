import java.util.Date;

public class UserInformation
{
	String firstName;
	String lastName;
	String email;
	String phoneNo;
	String address;
	String occupation;
	String gender;
	
	int birthdate;

	public UserInformation(String firstName, String lastName, String email, String phoneNo, String address,
			String occupation, String gender, int birthdate)
	{
		this.firstName = firstName;
		this.lastName = lastName;
		this.email = email;
		this.phoneNo = phoneNo;
		this.address = address;
		this.occupation = occupation;
		this.gender = gender;
		this.birthdate = birthdate;
	}

	public String toString()
	{
		return  firstName + "\n" + lastName + "\n" + email + "\n"
				+ phoneNo + "\n" + address + "\n" + occupation + "\n" + gender
				+ "\n" + birthdate;
	}
	/*public static void main(String[] args)
	{
		UserInformation u = new UserInformation("ra","pa","wnd","62527322","f-30","Serviceatyash","female",12-06-2000);
		System.out.println(u.toString());
	}*/
	
	
	
}