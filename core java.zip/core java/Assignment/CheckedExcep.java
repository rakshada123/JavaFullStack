import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.FileInputStream;
class CheckedExcep
{
	public static void main(String[] args) throws IOException,FileNotFoundException
	{
		FileInputStream f = null;
		f = new FileInputStream("d:/yash/abc.txt");
		int k;
		while((k=f.read()) != -1)
		{
			System.out.print((char)k);
		}
		f.close();
		try {
			Class.forName("myPackage.example.Sample");
		}catch (ClassNotFoundException ex) {
			ex.printStackTrace();
		}
	}
}