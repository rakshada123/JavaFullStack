import java.io.*;
class UncheckedExcep
{
	public static void main(String[] args)
	{
		try{
			int a=30,b=0;
			int output=a/b;
			System.out.println ("Result: "+output);
			int arr[]=new int[10];
			arr[11] = 3;
			int num=Integer.parseInt ("XYZ") ;
			System.out.println(num);
			String str="Rakshada Pant";
			System.out.println(str.length());;
			char c = str.charAt(0);
			c = str.charAt(40);
			System.out.println(c);
			String s=null;
			System.out.println(s.length());
		}
		catch(ArithmeticException e){
			System.out.println ("You Shouldn't divide a number by zero");
		}
		catch(ArrayIndexOutOfBoundsException e){
			System.out.println("ArrayIndexOutOfBoundException");
		}
		catch(NumberFormatException e){
			System.out.println("Number format exception occurred");
		}
		catch(StringIndexOutOfBoundsException e){
			System.out.println("StringIndexOutOfBoundsException!!");
		}
		catch(NullPointerException e){
			System.out.println("NullPointerException..");
		}
	}
}