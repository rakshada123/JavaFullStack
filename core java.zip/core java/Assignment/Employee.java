import java.io.*;
import java.util.Scanner;
class EmployeeDetails implements Serializable {
	
	double salary;
	String name, address, department;   

	public double getSalary() {  
		return salary;  
	}  
	public void setSalary(double salary) {  
		this.salary = salary;  
	}  
	public String getName() {  
		return name;  
	}  
	public void setName(String name) {  
		this.name = name;  
	}  
	public String getAddress() {  
		return address;  
	}  
	public void setAddress(String address) {  
		this.address = address;  
	}  
	public String getDepartment() {  
		return department;  
	}  
	public void setDepartment(String department) {  
		this.department = department;  
	}  
	public String toString() {  
		return name + " " + department;
	}
	public String tostring()
	{
		return salary+ "" +name +" " +department + " " +address;
	}
      
}  
public class Employee{  
     
    public static void main(String args[]) throws Exception {
	    EmployeeDetails e=new EmployeeDetails();
		System.out.println("Enter EmpName");
		Scanner n=new Scanner(System.in);
		String name=n.next();
		e.setName(name);
		System.out.println("Enter Department");
		Scanner d=new Scanner(System.in);
		String department=d.next();
		e.setDepartment(department);
		System.out.println("Enter address");
		Scanner ad=new Scanner(System.in);
		String address=ad.next();
		e.setAddress(address);
		System.out.println("Enter Salary");
		Scanner s=new Scanner(System.in);
		double salary=s.nextDouble();
		e.setSalary(salary);
	
		File f=new File("d:/yash/xyz.txt");
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		EmployeeDetails r=(EmployeeDetails)ois.readObject();
		ois.close();
		System.out.println(r);
	}
}