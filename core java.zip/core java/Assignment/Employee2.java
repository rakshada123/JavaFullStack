import java.io.*;
class Employee implements Serializable
{
	double salary;
	String name;
	String department;
	String designation;
	Employee(double salary,String name,String department,String designation)
	{    
	    this.salary=salary;
		this.name=name;
		this.department=department;
		this.designation=designation;	
		
	}
	public String tostring()
	{
		return salary+" "+name +" " +department + " " +designation;
	}
}
class Employee2
{
	public static void main(String[] args) throws Exception
	{
		Employee e= new Employee(11,"Rakshada","CSE","Intern");
		System.out.println(e);
		File f=new File("d:/yash/xyz.txt");
		f.createNewFile();
		ObjectOutputStream oos=new ObjectOutputStream(new FileOutputStream(f));
		oos.writeObject(e);
		oos.close();
	
		
		ObjectInputStream ois =new ObjectInputStream(new FileInputStream(f));
		Employee r=(Employee)ois.readObject();
		ois.close();
		System.out.println(r);
	}
}