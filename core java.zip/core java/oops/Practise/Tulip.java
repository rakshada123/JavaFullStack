abstract class flower()
{
	abstract void color();
	void show()
	{
		System.out.println("Beauty of flower");
	}
}
class Rose extends flower
{
	void display()
	{
		System.out.println("Fragrance of flower");
	}
}
class Tulip extends flower
{
	void display()
	{
		System.out.println("Smell of flower");
	}
	public static void main(String[] args)
	{
		Rose r=new Rose();
		r.display();
		Tulip t = new Tulip();
		t.show();
		t.display();
	}
}
	