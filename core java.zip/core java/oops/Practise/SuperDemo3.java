class Animal
{
	Animal()
	{
		System.out.println("class A constructor");
	}
}
class SuperDemo3 extends Animal
{
	SuperDemo3()
	{
		//super(); - called by default
		System.out.println("SuperDemo constructor");
	}
	public static void main(String[] args)
	{
		SuperDemo3 s = new SuperDemo3();
	}
}