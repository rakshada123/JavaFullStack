class A
{
	int a=10;
}
class SuperKeyDemo extends A
{
	int a=20;
	void display(int a)
	{
		System.out.println(a);
		System.out.println(this.a);
		System.out.println(super.a);
	}
	public static void main(String[] args)
	{
		SuperKeyDemo d=new SuperKeyDemo();
		sd.display(50);
	}
}
		