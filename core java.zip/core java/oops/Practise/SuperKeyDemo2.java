class A
{
	void show()
	{
		System.out.println("show A display");
	}
}
class SuperKeyDemo2 extends A
{
	void show()
	{
		System.out.println("show SuperKey");
	}
	void display()
	{
		show();
		super.show();
	}
	public static void main(String[] args)
	{
		SuperKeyDemo2 s = new SuperKeyDemo2();
		s.display();
	}
}