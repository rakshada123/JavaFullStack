class Classcast {
    void name(String str) {
    System.out.println("Name");
    }
}

class A extends Classcast {
    void name(String str) {
    System.out.println("Surname A");
    }
}

class B extends A{
	void name(String str) {
        System.out.println("Surname B");
  }
}

public class Exclasscast {
    public static void main(String[] args) {
        Classcast a = new Classcast();
        B b = (B) new A();
    }
}