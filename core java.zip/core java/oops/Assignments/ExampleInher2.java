class Person
{
	String name,dob;
	Person(String name,String dob)
	{
		this.name = name;
		this.dob = dob;
	}
}
class Teacher extends Person{
	double salary;
	String subject;
	Teacher(String name,String dob,String subject,double salary)
	{
		super(name,dob);
		this.subject=subject;
		this.salary=salary;
	}
	void display()
	{
		System.out.println("Name:"+name+" "+dob+" "+subject+" "+salary);
	}
}
class Student extends Person{
	int studentId;
	Student(String name,String dob,int studentId)
	{
		super(name,dob);
		this.studentId=studentId;
	}
}
class CollegeStudent extends Student{
	String collegeName;
	String year;
	CollegeStudent(String name,String dob,int studentId,String collegeName,String year)
	{
		super(name,dob,studentId);
		this.year=year;
		this.collegeName=collegeName;
	}
	void display()
	{
		System.out.println(name+" "+dob+" "+studentId+" "+year+" "+collegeName);
	}
}
public class ExampleInher2
{
	public static void main(String[] args)
	{
		Teacher t=new Teacher("Jaynam","27/07/1991","JAVA",90000);
		CollegeStudent cs=new CollegeStudent("R","25/01/20",1001,"fourth","medicaps");
		cs.display();
	}
}