class Television
{
	abstract void display()
	{
		System.out.println("parent class");
	}
}
class Samsung extends Television
{
	void display()
	{
		System.out.println("child class");
	}
}
class LG extends Television{
	void display()
	{
		System.out.println("child 2 class");
	}
	public static void main(String[] args)
	{
		LG a2 = new LG();
		a2.display();
		Samsung s = new Samsung();
		s.display();
	}
}
		