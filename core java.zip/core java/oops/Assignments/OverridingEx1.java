class Fruit
{
	String name;
	String taste;
	int size;
	Fruit()
	{
		name="fruit name";
		taste="fruit taste";
		size=0;
	}
	void eat()
	{
		System.out.println("Name:"+name+" "+"Taste:"+taste);
	}
}
class Apple extends Fruit{
	void eat()
	{
		System.out.println("tastes like apple");
	}
}
class Orange extends Fruit{
	void eat()
	{
		System.out.println("tastes like orange");
	}
}
public class OverridingEx1 {

	public static void main(String[] args) {
		new Fruit().eat();
		new Apple().eat();
		new Orange().eat();
	}
}


		