interface Novel
{
	void display();
}
interface Textbook 
{
	void show();
}
class MultiDemo implements Novel,Textbook 
{
	public void show()
	{
		System.out.println("show Textbook");
	}
	public void display()
	{
		System.out.println("display novel");
	}
	public static void main(String[] args)
	{
		MultiDemo md=new MultiDemo();
		md.show();
		md.display();
	}
}