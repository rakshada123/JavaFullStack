class Author
{
	String name;
	String email;
	char gender;
	Author(String name,String email,char gender)
	{
		this.name = name;
		this.email = email;
		this.gender = gender;
	}
	public String getName()
	{
		return name;
	}
	public String getEmail()
	{
		return email;
	}
	public char getGender()
	{
		return gender;
	}
	public String toString()
	{
		return name+" "+email+" "+gender;
	}		
}
public class Book extends Author
{
	public static void main(String[] args){
	
		String name1;
			//Author author = new Author("Rakshada","rt@gmail.com",f);
			//author.setAuthor("Rakshada","@gmail",'F');
		double price;
		int qtyInStock;
		Book(String name1,double price,int qtyInStock,String name,String email,char gender);
		{
			this.name1 = name1;
			this.price = price;
			this.qtyInStock = qtyInStock;
			super(name,email,gender);
		}
		void display()
		{
			System.out.println(name1+" "+price+qtyInStock+name+email+gender);
		}
		Author a = new Author("Rakshada","rs@gmail.com",'f');
		Book b = new Book("R",353,5,"Raks","Rse@gmail.com",'m');
		b.display();
			
	}
}

