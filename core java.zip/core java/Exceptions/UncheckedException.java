class UncheckedException
{
	public static void main(String[] args)
	{
		System.out.println("yash");
		System.out.println("Technologies");
		System.out.println("jaynam");
		System.out.println("Bye");
		System.out.println(100/0);
	}
}