import java.io.FileInputStream;
class CheckedException
{
	public static void main(String[] args)
	{
	try{
		FileInputStream f = new FileInputStream("D:/xyz.txt");
	}
	catch(Exception e)
	{
		System.out.println(e);
	}
		
	/*{
		FileInputStream f = new FileInputStream("D:/xyz.txt");
	}*/
	}
}
		