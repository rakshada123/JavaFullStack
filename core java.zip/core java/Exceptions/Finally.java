class Finally
{
	public static void main(String[] args)
	{
		try
		{
			int a=100, b=0, c=0;
			//c=a/b;
			System.out.println(c);
			System.exit(0);
		}
		/*catch(ArithmeticException e)
		{
			e.printStackTrace();
			System.out.println(e);
			System.out.println(e.getMessage());
		}*/
		finally
		{
			System.out.println("In finally block");
		}
	}
}