import java.util.Scanner;
class Exception1
{
	public static void main(String[] args)
	{
		try
		{
			Scanner s = new Scanner(System.in);
			String input = s.nextLine();
			int a=Integer.parseInt(input);
			System.out.println(a);
			System.out.println("Square"+a*a);
			
		}
		catch(NumberFormatException e)
		{
			System.out.println("Entered input is not a valid format of integer");
		}
	}
}