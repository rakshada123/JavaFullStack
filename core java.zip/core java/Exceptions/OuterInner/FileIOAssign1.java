import java.io.*;
  
public class FileIOAssign1 {
    public static void main(String[] args) throws IOException
    {
        FileInputStream f = new FileInputStream("d:/yash/yash.txt");
        InputStreamReader is = new InputStreamReader(f);
        BufferedReader br = new BufferedReader(is);
  
        String line;
        int wordCount = 0;
        int charCount = 0;
        int SpaceCount = 0;
		int lineCount = 0;
		int paraCount = 0;
  
        while ((line = br.readLine()) != null) {
            if (line.equals("")) {
                paraCount += 1;
            }
            else {
                charCount += line.length();
                String words[] = line.split("\\s+");
                wordCount += words.length;
                SpaceCount += wordCount - 1;
				String s[] = line.split("[!?.:]+");
                lineCount += s.length;
                
            }
        }
		if (lineCount >= 1) {
            paraCount++;
        }
        System.out.println("word count = "+ wordCount);
		System.out.println("number of lines = "+ lineCount);
        System.out.println("number of characters = "+ charCount);
        System.out.println("number of whitespaces = "+ SpaceCount);
    }
}