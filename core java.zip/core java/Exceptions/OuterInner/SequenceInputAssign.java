import java.io.*;    
class SeqInputAssign{  
  
	public static void main(String args[])throws Exception{    
		FileInputStream f1=new FileInputStream("D:\\filein1.txt");    
		FileInputStream f2=new FileInputStream("D:\\filein2.txt");    
		FileOutputStream fout=new FileOutputStream("D:\\fileout.txt");      
		SequenceInputStream t=new SequenceInputStream(f1,f2);    
		int i;    
		while((i=t.read())!=-1)    
		{    
			fout.write(i);        
		}    
		t.close();    
		fout.close();      
		f1.close();      
		f2.close();
	}
}	