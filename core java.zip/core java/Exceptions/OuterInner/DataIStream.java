import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
public class DataIStream 
{
	public static void main(String[] args) throws IOException
	{ 
		FileInputStream f = new FileInputStream("d:/yash/abc.txt");  
		DataInputStream i = new DataInputStream(f);  
		int count = f.available();  
		byte[] array = new byte[count];  
		i.read(array);  
		for (byte b : array) {  
			char ch = (char) b;  
			System.out.print(ch);  
		}  
	}  
}
