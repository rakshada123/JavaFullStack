import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileOutputStream;
class FileInputOutputStream throws IOException{
	public static void main(String[] args)
	{
		//FileInputStream in=new FileInputStream("d:/yash/abc.txt");
		//FileOutputStream out=new FileOutputStream("d:/yash/xyz.txt");
		FileInputStream in=null;
		FileOutputStream out=null;
		try{
			in=new FileInputStream("d:/yash/abc.txt");
			out=new FileOutputStream("d:/yash/xyz.txt",true);//append
			int c;
			while((c=in.read())!=-1)
			{
				out.write(c);
				System.out.println((char)c);
			}
		}
		catch(IOException e)
		{
			e.printStackTrace();
		}
		finally
		{
			if(in!=null){
				in.close();
			}
			if(out!=null){
				out.close();
			}
		}//or we can add try catch in finally block if we dont want to use throws in main method
	}

}
		