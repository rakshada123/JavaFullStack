
import java.io.*;

public class FileIOAssign2 {
	public static void main(String[] args) throws IOException
	{
		FileInputStream f = new FileInputStream("d:/yash/yash.txt");
        InputStreamReader is = new InputStreamReader(f);
        BufferedReader br = new BufferedReader(is);
		String c;
		
        
		
		int count=0;
		int a=0, e=0, i=0, o=0, u=0;
		while ((c = br.readLine()) != null) {
			for (int x = 0; x < c.length(); x++) {
				
				if (c.charAt(x) == 'a' || c.charAt(x) == 'e' || c.charAt(x) == 'i' || c.charAt(x) == 'o' || c.charAt(x) == 'u')
				{
					count++;
				}
			}
			for(int y=0 ; y<c.length(); y++){
				if (c.charAt(y) == 'a'){
					a++;
				}
				if (c.charAt(y) == 'e'){
					e++;
				}
				if (c.charAt(y) == 'i'){
					i++;
				}
				if (c.charAt(y) == 'o'){
					o++;
				}
				if (c.charAt(y) == 'u'){
					u++;
				}
			}
		}

		System.out.println("Total no of vowels are: " + count);
		System.out.println("Total no of a: " + a);
		System.out.println("Total no of e: " + e);
		System.out.println("Total no of i: " + i);
		System.out.println("Total no of o: " + o);
		System.out.println("Total no of u: " + u);
		
	}
}
