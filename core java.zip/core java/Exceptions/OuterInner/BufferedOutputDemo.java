import java.io.FileOutputStream;
import java.io.IOException;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
class BufferedOutputDemo
{
	public static void main(String[] args)
	{
		try{
		
			FileInputStream in= new FileInputStream("d:/abc.txt");
			BufferedInputStream bin= new BufferedInputStream(in);
			FileOutputStream out= new FileOutputStream("d:/xyz.txt");
			BufferedOutputStream bout= new BufferedOutputStream(out);
		
		 
			int c;
			while((c=bin.read())!=-1)
			{
				bout.write(c);
		
			}
			bin.close(); 
			in.close();
			bout.close();   
			out.close();
		 
		 
		}
		catch(Exception e){
			e.printStackTrace();
		 
		}  
		 
	 
	  
	}
}