import java.io.ByteArrayOutputStream;
import java.io.ByteArrayInputStream;

class ByteArrayIOStream{
  public static void main(String[] args) {

    String t = "Welcome";
	byte[] arr1={12,13,14,15};

    try {
      ByteArrayOutputStream out = new ByteArrayOutputStream();
	  ByteArrayInputStream input=new ByteArrayInputStream(arr1);
      byte[] array = t.getBytes();

      out.write(array);

      String a = out.toString();
      System.out.println("Output stream: " + a);
	  for(int i=0;i<arr1.length;i++){
		  int d=input.read();
		  System.out.print(d+" ");
	  }
	  input.close();

      out.close();
    }

    catch(Exception e) {
      e.getStackTrace();
    }
  }
}
