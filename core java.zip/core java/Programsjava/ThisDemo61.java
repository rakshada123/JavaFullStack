class ThisDemo6
{
	ThisDemo6 result()
	{
		return this;
	}
	void display()
	{
		System.out.println("Welcome");
	}
}
class ThisDemo61
{
	public static void main(String[] args)
	{
		ThisDemo6 s = new ThisDemo6();
		s.result().display();
		//s.display();
	}
}