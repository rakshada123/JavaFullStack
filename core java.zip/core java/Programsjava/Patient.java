class Patient
{
	int x,y;
	String a;
	Patient(String a,int x,int y)
	{
		this.a=a;
		this.x=x;
		this.y=y;
		System.out.println("Name:"+a+" "+"Height:"+x+" "+"Weight:"+y);
	}
	double computeBMI()
	{
		double b = y/x;
		double bs = b/x;
		return(bs);
	}
	public static void main(String[] args)
	{
		Patient p = new Patient("Arya",10,20);
		System.out.println(p.computeBMI());
	}
}