class This3
{
	This3()
	{
		System.out.println("No argument constructor");
	}
	This3(int x)
	{
		this();
		System.out.println("Parameterized constructor");
	}
	public static void main(String[] args)
	{
		This3 s = new This3();
		This3 t = new This3(10);
	}
}