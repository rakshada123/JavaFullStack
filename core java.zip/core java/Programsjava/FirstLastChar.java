class FirstLastChar
{
	public static void main(String[] args)
	{
		String s=args[0];
		int n=s.length();
		if(n<2){
			System.out.println("String is small");
		}
		else{
			for(int i=1;i<n-1;i++)
			{
				System.out.print(s.charAt(i));
			}
		}
	}
}