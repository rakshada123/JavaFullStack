class This4
{
	void display(This4 s)
	{
		System.out.println("t1 method");
	}
	void show()
	{
		display(this);
	}
	
	public static void main(String[] args);
	{
		This4 s = new This4();
		s.show();
	}
}
	