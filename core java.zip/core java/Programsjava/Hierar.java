class Hierar
{
	void display()
	{
		System.out.println("A Class");
	}
}
class Hierar1 extends Hierar
{
	void display1()
	{
		System.out.println("B class");
	}
} 
class Hierar2 extends Hierar
{
	public static void main(String[] args)
	{
		Hierar2 o = new Hierar2();
		o.display();
		o.display2();
	}
	void display2()
	{
		System.out.println("C class");
	}
}