class DemoConstructor
{
	String name;
	int emp_id;
	DemoConstructor(String name,int emp_id)
	{
		this.name=name;
		this.emp_id = emp_id;
		System.out.println(name + " " + emp_id);
		
	}
	public DemoConstructor()
	{
		System.out.println("Default Constructor");
	}
	public static void main(String[] args)
	{
		DemoConstructor e1 = new DemoConstructor();
		DemoConstructor e2 = new DemoConstructor("Rakshada",10);
		
	}
}
	