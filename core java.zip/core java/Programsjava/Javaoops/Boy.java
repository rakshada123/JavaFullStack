class overriding{
	String run()
	{
		String s = "as";
		System.out.println("Object method");
		return(s);
	}
}
class Boy extends overriding
{
	
	Object run()
	{
		System.out.println("Boy is running");
		return(0);
	}
	public static void main(String[] args)
	{
		Boy c = new Boy();
		c.run();
		overriding o = new overriding();
		o.run();
		
	}
}