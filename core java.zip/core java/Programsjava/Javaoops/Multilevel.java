class Multilevel
{
	void show()
	{
		System.out.println("show method");
	}
}
class Multilevel1 extends Multilevel{
	void run()
	{
		System.out.println("run method");
	}
}
class Multilevel2 extends Multilevel1
{
	public static void main(String[] args)
	{
		Multilevel2 o = new Multilevel2();
		o.run();
		o.show();
	}
}