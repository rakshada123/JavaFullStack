public class Fruit
{
	String name;
	String taste;
	int size;
	public Fruit()
	{
		name="fruit name";
		taste="fruit taste";
		size=0;
	}
	public void eat()
	{
		System.out.println("Name:"+name+" "+"Taste:"+taste);
	}
}
public class Apple extends Fruit{
	public void eat()
	{
		System.out.println("tastes like apple");
	}
}
public class Orange extends Fruit{
	void eat()
	{
		System.out.println("tastes like orange");
	}
	public static void main(String[] args)
	{
		Fruit f = new Fruit("kiwi","sweet",'4');
		
	}
}

		