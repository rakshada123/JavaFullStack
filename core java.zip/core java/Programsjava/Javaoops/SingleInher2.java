class SingleInher
{
	void run()
	{
		System.out.println("Run");
	}
}
class SingleInher2 extends SingleInher
{
	public static void main(String[] args)
	{
		SingleInher2 d = new SingleInher2();
		d.run();
	}
}