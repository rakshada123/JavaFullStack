class ThisDemo2
{
	void disp()
	{
		System.out.println("Welcome");
	}
	void show()
	{
		disp();
	}
	public static void main(String[] args)
	{
		ThisDemo2 s = new ThisDemo2();
		s.show();
	}
}