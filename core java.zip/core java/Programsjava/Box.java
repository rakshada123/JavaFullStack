class Box
{
	int x,y,z;
	Box(int x,int y,int z)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		System.out.println("Height:"+x+" "+"Width:"+y+" "+"Depth:"+z);
	}
	int volume()
	{
		int v = x*y*z;
		return(v);
	}
	public static void main(String[] args)
	{
		Box b = new Box(10,20,30);
		System.out.println(b.volume());
	}
}
		