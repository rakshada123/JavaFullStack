class ThisDemo5
{
	int a=0,b=0;
	public ThisDemo5(ThisDemo51 td)
	{
		System.out.println("ThisDemo5 class constructor");
	}
}
class ThisDemo51
{
	void x1()
	{
		ThisDemo5 ts = new ThisDemo5(this);
	}
	public static void main(String[] args)
	{
		ThisDemo51 t = new ThisDemo51();
		t.x1();
	}
}