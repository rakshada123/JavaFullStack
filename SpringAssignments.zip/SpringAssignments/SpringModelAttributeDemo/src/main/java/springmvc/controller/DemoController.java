package springmvc.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class DemoController {

	@RequestMapping("/home")
	public String home(Model model) {
		model.addAttribute("name", "Hritik");

		ArrayList<String> list = new ArrayList<String>();
		list.add("Hritik");
		list.add("Manesh");
		list.add("Sunil");
		list.add("Hardik");
		list.add("Shruti");

		model.addAttribute("list", list);
		return "index";

	}

	@RequestMapping(path = "/request", method = RequestMethod.POST)
	public String handlerequest(@ModelAttribute("emp") Employee emp, Model model) {
		return "test";
	}
}
