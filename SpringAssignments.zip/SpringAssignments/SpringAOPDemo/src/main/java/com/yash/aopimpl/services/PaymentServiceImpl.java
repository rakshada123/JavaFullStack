package com.yash.aopimpl.services;

public class PaymentServiceImpl implements PaymentService {

	public void makePayment() {

		System.out.println("Debit code");

		System.out.println("Credit code");

	}

}