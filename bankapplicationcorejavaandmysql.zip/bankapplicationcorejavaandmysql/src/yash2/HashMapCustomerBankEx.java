package yash2;

import java.io.BufferedReader;
import java.util.Scanner;
import yash.BankAccount;
import yash.Customer;


import java.io.InputStreamReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.HashMap;
import java.util.Map;

public class HashMapCustomerBankEx {
	private static Map<Customer,BankAccount> map;

	public static void main(String[] args) {
		map = new HashMap<>();
		Customer c1 = new Customer(1,"A");
		Customer c2 = new Customer(2,"B");
		Customer c3 = new Customer(3,"c");
		BankAccount b1=new BankAccount(3333, 10000, c1);
		BankAccount b2=new BankAccount(4444, 12000, c2);
		BankAccount b3=new BankAccount(5555, 15000, c3);
		map.put(c1, b1);
		map.put(c2, b2);
		map.put(c3, b3);
		Customer temp=new Customer(1,"A");
		BankAccount tempAct=map.get(temp);
		System.out.println("Customer Account Details.");
		System.out.print(tempAct.getActCustomer().getCustomerId()+" ");
		System.out.print(tempAct.getActCustomer().getCustomerName()+" ");
		System.out.print(tempAct.getAccountNumber()+" ");
		System.out.println(tempAct.getBalance());
		
		
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//creating connection
			String url="jdbc:mysql://localhost:3306/bank";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			//creating query
			String q="insert into Account(accountNumber,balance,actCustomer) values(?,?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter account Number:");
			int id = Integer.parseInt(br.readLine());
			System.out.println("Enter amount to store balance:");
			int id2 = Integer.parseInt(br.readLine());
			System.out.println("Enter account customer");
			String name=br.readLine();
			
			//setting the values
			ps.setInt(1,id);
			ps.setInt(2,id2);
			ps.setString(3, name);
			ps.executeUpdate();
			System.out.println("inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	    
	}

}