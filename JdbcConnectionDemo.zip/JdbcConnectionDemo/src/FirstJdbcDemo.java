
import java.sql.*;
class FirstJdbcDemo
{
	public static void main(String[] args)
	{
		try
		{
			//1)load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//2)create connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			if(con!=null)
			{
				System.out.println("connection created successfully");
			}
			else
			{
				System.out.println("Connection not created");
			}//Step 3:create query
			String q="select * from employee";
			Statement st=con.createStatement();
			ResultSet set=st.executeQuery(q);
			//step 4: process the data
			while(set.next())
			{
				int id=set.getInt("empID");//(1)-- column name
				String name=set.getString("name");//(2) -- column name
				System.out.println("id:" + id);
				System.out.println("name:" + name);
			}
			//Step 5:connection close	
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}