
import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
public class InsertTextFile {
	public static void main(String args[]) throws Exception{
	      //Registering the Driver
	      DriverManager.registerDriver(new com.mysql.jdbc.Driver());
	      //Getting the connection
	      String mysqlUrl = "jdbc:mysql://localhost:3306/yash";
	      Connection con = DriverManager.getConnection(mysqlUrl, "root", "root");
	      System.out.println("Connection established......");
	      String query = "INSERT INTO Articles(Name, Article) VALUES(?,?)";
	      PreparedStatement pstmt = con.prepareStatement(query);
	      pstmt.setString(1, "my article");
	      FileReader reader = new FileReader("C:\\Users\\Rakshada.Pant\\Documents\\my article.txt");
	      pstmt.setCharacterStream(2, reader);
	      pstmt.execute();
	      System.out.println("Data inserted");
	}
}
