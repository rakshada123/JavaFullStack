
import java.sql.*;
import java.io.*;
class InsertDemo
{
	public static void main(String[] args)
	{
		Statement stmt = null;
		try
		{
			//load the driver
			Class.forName("com.mysql.jdbc.Driver");
			//creating connection
			String url="jdbc:mysql://localhost:3306/yash";
			String user="root";
			String pass="root";
			Connection con=DriverManager.getConnection(url, user, pass);
			//creating query
			String q="insert into employee(empID,name) values(?,?)";
			PreparedStatement ps=con.prepareStatement(q);
			BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Enter EmpID:");
			int id = Integer.parseInt(br.readLine());
			System.out.println("Enter name:");
			String name=br.readLine();
			stmt = (Statement) con.createStatement();//used to update the record 
			String query1 = "update employee " + "set name='Johnson' " + "where EmpID in(1,4)";
	        stmt.executeUpdate(query1);
	        System.out.println("Record has been updated in the table successfully");
			
			//setting the values
			ps.setInt(1,id);
			ps.setString(2,name);
			ps.executeUpdate();
			System.out.println("inserted Successfully");
			con.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
}
