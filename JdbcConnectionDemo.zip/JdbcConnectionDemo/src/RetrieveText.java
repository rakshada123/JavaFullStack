import java.io.*;  
import java.sql.*;  
  
public class RetrieveText {  
public static void main(String[] args) {  
try{  
Class.forName("com.mysql.jdbc.Driver");

String mysqlUrl = "jdbc:mysql://localhost:3306/yash";
Connection con = DriverManager.getConnection(mysqlUrl, "root", "root");

System.out.println("Connection established......");
              
PreparedStatement ps=con.prepareStatement("select * from articles");  
ResultSet rs=ps.executeQuery();  
rs.next();//now on 1st row  
              
Clob c=rs.getClob(2);  
Reader r=c.getCharacterStream();              
              
FileWriter fw=new FileWriter("C:\\Users\\Rakshada.Pant\\Documents\\my article");  
              
int i;  
while((i=r.read())!=-1)  
fw.write((char)i);  
              
fw.close();  
con.close();  
              
System.out.println("success");  
}catch (Exception e) {e.printStackTrace();  }  
}  
}  
