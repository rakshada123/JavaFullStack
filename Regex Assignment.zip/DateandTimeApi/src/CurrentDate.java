import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
public class CurrentDate {
  public static void main(String[] args) {
    LocalDate ob = LocalDate.now();
    System.out.println(ob);
    LocalTime ob2=LocalTime.now();
    System.out.println(ob2);
    LocalDateTime ob3=LocalDateTime.now();
    System.out.println(ob3);
    
  }
}
