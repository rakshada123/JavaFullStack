import java.time.LocalDateTime; 
import java.time.format.DateTimeFormatter; 

public class FormatDateTime {
  public static void main(String[] args) {
    LocalDateTime d = LocalDateTime.now();
    System.out.println("Before formatting: " + d);
    DateTimeFormatter f = DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss");

    String formattedDate = d.format(f);
    System.out.println("After formatting: " + formattedDate);
  }
}