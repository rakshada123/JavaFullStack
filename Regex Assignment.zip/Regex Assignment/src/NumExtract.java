import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public class NumExtract {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
	    System.out.println("Enter text: ");
	    String data = sc.nextLine();
	    String regex = "\\d+";//expression to match num in string
	    Pattern pattern = Pattern.compile(regex);
	    Matcher matcher = pattern.matcher(data);
	      System.out.println("Digits in the text are: ");
	      while(matcher.find()) {
	         System.out.print(matcher.group()+" ");
	      }
	   }
	}


