import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ExtractSubstring {
    public static void main(String[] args) {
        Pattern pattern = Pattern.compile(".*'([^']*)'.*");
        Scanner sc = new Scanner(System.in);
	    System.out.println("Enter text: ");
	    String data = sc.nextLine();

        Matcher matcher = pattern.matcher(data);
        if(matcher.matches()) {
            System.out.println(matcher.group(1));
        }

    }
}
